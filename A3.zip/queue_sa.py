# Name: Karl Mellinger
# OSU Email: mellinka@oregonstate.edu
# Course: CS261 - Data Structures
# Assignment: 3
# Due Date: 5/2/2022
# Description: Implementing a queue using a StaticArray


from static_array import StaticArray


class QueueException(Exception):
    """
    Custom exception to be used by Queue class
    DO NOT CHANGE THIS METHOD IN ANY WAY
    """
    pass


class Queue:
    def __init__(self) -> None:
        """
        Initialize new queue based on Static Array
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self._sa = StaticArray(4)
        self._front = 0
        self._back = -1
        self._current_size = 0

    def __str__(self) -> str:
        """
        Return content of stack in human-readable form
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        size = self._current_size
        out = "QUEUE: " + str(size) + " element(s). ["

        front_index = self._front
        for _ in range(size - 1):
            out += str(self._sa[front_index]) + ', '
            front_index = self._increment(front_index)

        if size > 0:
            out += str(self._sa[front_index])

        return out + ']'

    def is_empty(self) -> bool:
        """
        Return True is the queue is empty, False otherwise
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._current_size == 0

    def size(self) -> int:
        """
        Return number of elements currently in the queue
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._current_size

    def _increment(self, index: int) -> int:
        """
        Move index to next position
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """

        # employ wraparound if needed
        index += 1
        if index == self._sa.length():
            index = 0

        return index

    # -----------------------------------------------------------------------

    #enqueue takes an object value and adds it to the end of the queue.
    def enqueue(self, value: object) -> None:
        if self.size() == self._sa.length()-1:
            self._double_queue()
        self._back = self._increment(self._back)
        self._sa[self._back] = value
        self._current_size += 1

    #dequeue removes the first object in the queue and returns it. Throws a QueueException if there are no elements in the queue.
    def dequeue(self) -> object:
        if self.size() == 0:
            raise QueueException
        tempVal = self._sa[self._front]
        self._sa[self._front] = None
        self._front = self._increment(self._front)
        self._current_size -= 1
        return tempVal

    #front returns the front element in the queue without removing it. Throws a QueueException if there are no elements in the queue.
    def front(self) -> object:
        if self.size() == 0:
            raise QueueException
        return self._sa[self._front]

    # The method below is optional, but recommended, to implement. #
    # You may alter it in any way you see fit.                     #

    #_double_queue doubles the size of 'this' SA; to be used in event of enqueue with a full array.
    def _double_queue(self) -> None:
        temp = StaticArray(self._sa.length()*2)
        i = 0
        currentIndex = self._front
        currentVal = self._sa[currentIndex]
        while i < self.size():
            temp[i] = currentVal
            currentIndex = self._increment(currentIndex)
            currentVal = self._sa[currentIndex]
            i += 1
        self._sa = temp
        


# ------------------- BASIC TESTING -----------------------------------------

if __name__ == "__main__":

    print("\n# enqueue example 1")
    q = Queue()
    print(q)
    for value in [1, 2, 3, 4, 5]:
        q.enqueue(value)
    print(q)

    print("\n# dequeue example 1")
    q = Queue()
    for value in [1, 2, 3, 4, 5]:
        q.enqueue(value)
    print(q)
    for i in range(q.size() + 1):
        try:
            print(q.dequeue())
        except Exception as e:
            print("No elements in queue", type(e))
    for value in [6, 7, 8, 111, 222, 3333, 4444]:
        q.enqueue(value)
    print(q)

    print('\n# front example 1')
    q = Queue()
    print(q)
    for value in ['A', 'B', 'C', 'D']:
        try:
            print(q.front())
        except Exception as e:
            print("No elements in queue", type(e))
        q.enqueue(value)
    print(q)
