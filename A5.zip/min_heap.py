# Name: Karl Mellinger
# OSU Email: mellinka@oregonstate.edu
# Course: CS261 - Data Structures
# Assignment: 5
# Due Date: 5/23/2022
# Description: Implementation of the minimum heap using a DynamicArray.


from dynamic_array import *


class MinHeapException(Exception):
    """
    Custom exception to be used by MinHeap class
    DO NOT CHANGE THIS CLASS IN ANY WAY
    """
    pass


class MinHeap:
    def __init__(self, start_heap=None):
        """
        Initialize a new MinHeap
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self._heap = DynamicArray()

        # populate MH with initial values (if provided)
        # before using this feature, implement add() method
        if start_heap:
            for node in start_heap:
                self.add(node)

    def __str__(self) -> str:
        """
        Return MH content in human-readable form
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        heap_data = [self._heap[i] for i in range(self._heap.length())]
        return 'HEAP ' + str(heap_data)

    def add(self, node: object) -> None:
        """
        add puts a new 'node' at the end of the dynamic array.
        params:
            node: object, the 'node' to append to the minheap.
        returns:
            None
        """
        self._heap.append(node)
        if self._heap.length() <= 1:
            return
        indexOfNode = self._heap.length()-1
        parentOfNode = self._heap[(indexOfNode-1)//2]
        while parentOfNode > node:
            self._heap[(indexOfNode-1)//2] = node
            self._heap[indexOfNode] = parentOfNode
            indexOfNode = (indexOfNode-1)//2
            if (indexOfNode-1) >= 0:
                parentOfNode = self._heap[(indexOfNode-1)//2]
            else:
                return



    def is_empty(self) -> bool:
        """
        is_empty checks to see if 'this' MinHeap is empty
        params:
            None
        returns:
            True if the heap is empty
            False if the heap is not empty
        """
        if self._heap.length() == 0:
            return True
        else:
            return False

    def get_min(self) -> object:
        """
        get_min returns the object with the minimum key in the heap. It does not remove this object. Throws MinHeapException if the heap is empty.
        params:
            None
        returns:
            the minimum object in the heap
        """
        if self.is_empty():
            raise MinHeapException
        return self._heap[0]
    
    def remove_min(self) -> object:
        """
        remove_min removes the minimum element in the heap and returns it. It then rearranges the heap to fill the minimum element. Throws MinHeapException if the heap 
        is empty.
        params:
            None
        returns:
            Minimum element in the heap.
        """
        if self.is_empty():
            raise MinHeapException
        if self._heap.length() == 1:
            temp = self._heap[0]
            self._heap[0] = None
            self._heap._size = 0
            return temp
        removalNode = self._heap[0]
        self._heap[0] = self._heap.pop()
        _percolate_down(self._heap, self._heap[0], 0, self._heap.length() - 1)
        return removalNode
            


    
    def build_heap(self, da: DynamicArray) -> None:
        """
        build_heap takes an incorrect heap as a DynamicArray and changes it into a correct heap.
        params:
            da: DynamicArray, the incorrect heap to be fixed
        returns:
            None
        """
        self._heap = DynamicArray()
        for i in range (da.length()):
            if i >= self._heap.length():
                self._heap.append(da[i])
            else:
                self._heap[i] = da[i]
        firstNonLeafIndex = (self._heap.length()//2)-1
        while firstNonLeafIndex >= 0:            
            firstNonLeaf = self._heap[firstNonLeafIndex]
            _percolate_down(self._heap, firstNonLeaf, firstNonLeafIndex, self._heap.length() - 1)
            firstNonLeafIndex -= 1
            


    def size(self) -> int:
        """
        size returns the number of elements in the heap
        params:
            None
        returns:
            an int of the number of elements in the heap
        """
        return self._heap.length()

    def clear(self) -> None:
        """
        clear removes all contents of the heap
        params:
            None
        returns:
            None
        """
        self._heap = DynamicArray()


def heapsort(da: DynamicArray) -> None:
    """
    heapsort takes a DynamicArray and sorts its contents in non-ascending order.
    params:
        da: DynamicArray, the array to be made into a sorted heap
    returns:
        None
    """
    firstNonLeafIndex = (da.length()//2)-1
    while firstNonLeafIndex >= 0:            
            firstNonLeaf = da[firstNonLeafIndex]
            _percolate_down(da, firstNonLeaf, firstNonLeafIndex, da.length() - 1)
            firstNonLeafIndex -= 1
    k = da.length() - 1
    while k > 0:
        da[0], da[k] = da[k], da[0]
        k -= 1
        _percolate_down(da, da[0], 0, k)
    

def _percolate_down(da: DynamicArray, parent: object, currentNodeIndex: int, indexToStopAt: int) -> None:
    """
    _percolate_down takes a heap as a DynamicArray and moves the top element (parent) down to its rightful place
    params:
        da: DynamicArray, the heap to be percolated through
        parent: object, the object to percolate down
        currentNodeIndex: int, the index to start at
        indexToStopAt: int, an index for HeapSort to stop percolation.
    returns:
        None
    """
    currentNode = parent
    while (2*currentNodeIndex) + 1 <= indexToStopAt:
            indexOfLeftChild = (currentNodeIndex*2)+1
            if (currentNodeIndex*2)+2 <= (indexToStopAt):
                indexOfRightChild = (currentNodeIndex*2) + 2
            else:
                if currentNode > da[indexOfLeftChild]:
                    temp = currentNode
                    da[currentNodeIndex] = da[indexOfLeftChild]
                    da[indexOfLeftChild] = temp
                    currentNodeIndex = indexOfLeftChild
                return

            minChild = min(da[indexOfLeftChild], da[indexOfRightChild])
            if currentNode <= minChild:
                return
            if currentNode > da[indexOfLeftChild] and da[indexOfLeftChild] == minChild:
                temp = currentNode
                da[currentNodeIndex] = da[indexOfLeftChild]
                da[indexOfLeftChild] = temp
                currentNodeIndex = indexOfLeftChild
            elif currentNode > da[indexOfRightChild] and da[indexOfRightChild] == minChild:
                temp = currentNode
                da[currentNodeIndex] = da[indexOfRightChild]
                da[indexOfRightChild] = temp
                currentNodeIndex = indexOfRightChild



# ------------------- BASIC TESTING -----------------------------------------


if __name__ == '__main__':

    print("\nPDF - add example 1")
    print("-------------------")
    h = MinHeap()
    print(h, h.is_empty())
    for value in range(300, 200, -15):
        h.add(value)
        print(h)

    print("\nPDF - add example 2")
    print("-------------------")
    h = MinHeap(['fish', 'bird'])
    print(h)
    for value in ['monkey', 'zebra', 'elephant', 'horse', 'bear']:
        h.add(value)
        print(h)

    print("\nPDF - is_empty example 1")
    print("-------------------")
    h = MinHeap([2, 4, 12, 56, 8, 34, 67])
    print(h.is_empty())

    print("\nPDF - is_empty example 2")
    print("-------------------")
    h = MinHeap()
    print(h.is_empty())

    print("\nPDF - get_min example 1")
    print("-----------------------")
    h = MinHeap(['fish', 'bird'])
    print(h)
    print(h.get_min(), h.get_min())

    print("\nPDF - remove_min example 1")
    print("--------------------------")
    h = MinHeap([1, 10, 2, 9, 3, 8, 4, 7, 5, 6])
    while not h.is_empty() and h.is_empty() is not None:
        print(h, end=' ')
        print(h.remove_min())

    print("\nPDF - build_heap example 1")
    print("--------------------------")
    da = DynamicArray([100, 20, 6, 200, 90, 150, 300])
    h = MinHeap(['zebra', 'apple'])
    print(h)
    h.build_heap(da)
    print(h)

    print("--------------------------")
    print("Inserting 500 into input DA:")
    da[0] = 500
    print(da)

    print("Your MinHeap:")
    print(h)
    if h.get_min() == 500:
        print("Error: input array and heap's underlying DA reference same object in memory")

    print("\nPDF - heapsort example 1")
    print("------------------------")
    da = DynamicArray([100, 20, 6, 200, 90, 150, 300])
    print(f"Before: {da}")
    heapsort(da)
    print(f"After:  {da}")

    print("\nPDF - heapsort example 2")
    print("------------------------")
    da = DynamicArray(['monkey', 'zebra', 'elephant', 'horse', 'bear'])
    print(f"Before: {da}")
    heapsort(da)
    print(f"After:  {da}")

    print("\nPDF - size example 1")
    print("--------------------")
    h = MinHeap([100, 20, 6, 200, 90, 150, 300])
    print(h.size())

    print("\nPDF - size example 2")
    print("--------------------")
    h = MinHeap([])
    print(h.size())

    print("\nPDF - clear example 1")
    print("---------------------")
    h = MinHeap(['monkey', 'zebra', 'elephant', 'horse', 'bear'])
    print(h)
    print(h.clear())
    print(h)
